<?php

$lang['scaff_view_records']		= '檢視紀錄';
$lang['scaff_create_record']	= '新增紀錄';
$lang['scaff_add']				= '新增資料';
$lang['scaff_view']				= '檢視資料';
$lang['scaff_edit']				= '編輯';
$lang['scaff_delete']			= '刪除';
$lang['scaff_view_all']			= '檢視全部';
$lang['scaff_yes']				= '是';
$lang['scaff_no']				= '否';
$lang['scaff_no_data']			= '目前資料表沒有資料存在.';
$lang['scaff_del_confirm']		= '你確定要刪除以下資料:';


/* End of file scaffolding_lang.php */
/* Location: ./system/language/chinese_traditional/scaffolding_lang.php */